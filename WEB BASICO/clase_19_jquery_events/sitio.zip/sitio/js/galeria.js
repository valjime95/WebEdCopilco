// JavaScript Document
$(document).ready(function(){
	'use strict';
	$('#uno').click(function(){
		$('#imgPrincipal').html('<img src="img/galery/salvavidas.jpg" alt="Salva vidas">');
	});
	$('#dos').click(function(){
		$('#imgPrincipal').html('<img src="img/galery/nadador.jpg" alt="Nadador">');
	});
	$('#tres').click(function(){
		$('#imgPrincipal').html('<img src="img/galery/amigos.jpg" alt="Amigos">');
	});
	$('#cuatro').click(function(){
		$('#imgPrincipal').html('<img src="img/galery/muelle.jpg" alt="Muelle">');
	});
});